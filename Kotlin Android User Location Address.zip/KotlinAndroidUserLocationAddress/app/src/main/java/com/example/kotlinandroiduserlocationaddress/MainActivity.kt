package com.example.kotlinandroiduserlocationaddress

import android.Manifest
import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.content.IntentFilter
import android.location.Geocoder
import android.location.Location
import android.os.Bundle
import android.util.Log
import android.view.View
import android.widget.Button
import android.widget.TextView
import android.widget.Toast
import androidx.activity.enableEdgeToEdge
import androidx.appcompat.app.AppCompatActivity
import androidx.core.view.ViewCompat
import androidx.core.view.WindowInsetsCompat
import androidx.localbroadcastmanager.content.LocalBroadcastManager
import java.io.IOException
import java.util.Locale

class MainActivity : AppCompatActivity() {

    private var btnGetAddress: Button? = null
    private var txtResult: TextView? = null
    private val foregroundLocationPermissions = arrayOf(
        Manifest.permission.ACCESS_FINE_LOCATION,
        Manifest.permission.ACCESS_COARSE_LOCATION
    )

    private var permissionManager: PermissionManager? = null
    private var locationManager: LocationManager? = null
    private var localBroadcastIntentFilter: IntentFilter? = null

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        setContentView(R.layout.activity_main)

        ViewCompat.setOnApplyWindowInsetsListener(findViewById(R.id.main)) { v, insets ->
            val systemBars = insets.getInsets(WindowInsetsCompat.Type.systemBars())
            v.setPadding(systemBars.left, systemBars.top, systemBars.right, systemBars.bottom)
            insets
        }

        btnGetAddress = findViewById(R.id.btnGetAddress)
        txtResult = findViewById(R.id.txtResult)

        permissionManager = PermissionManager.getInstance(this)
        locationManager = LocationManager.getInstance(
            this
        )

        localBroadcastIntentFilter = IntentFilter()
        localBroadcastIntentFilter?.addAction("foreground_location")

        btnGetAddress?.setOnClickListener { v: View? ->
            val geocoder = Geocoder(this@MainActivity, Locale.getDefault())
            if (!permissionManager!!.checkPermissions(foregroundLocationPermissions)) {
                permissionManager?.askPermissions(
                    this@MainActivity,
                    foregroundLocationPermissions, 100
                )
            } else {
                if (locationManager!!.isLocationEnabled) {
                    val location: Location? = locationManager?.lastLocation
                    if (location != null) {
                        try {
                            val addresses = checkNotNull(
                                geocoder.getFromLocation(
                                    location.latitude,
                                    location.longitude,
                                    1
                                )
                            )

                            val address = addresses[0]

                            val strAddress = """
                    Endereço: ${address.getAddressLine(0)}
                    Cidade: ${address.adminArea}
                    País: ${address.countryName}
                    Feature Name: ${address.featureName}
                    Locality: ${address.locality}
                    
                    """.trimIndent()

                            txtResult?.text = strAddress
                        } catch (e: IOException) {
                            e.printStackTrace()
                        }
                    } else {
                        Toast.makeText(
                            this@MainActivity, "Não foi possível obter a localização. Aguarde!",
                            Toast.LENGTH_SHORT
                        ).show()
                    }
                } else {
                    locationManager?.createLocationRequest()
                }
            }
        }
    }

    override fun onResume() {
        super.onResume()
        locationManager!!.startLocationUpdates()
        LocalBroadcastManager.getInstance(this@MainActivity).registerReceiver(
            foregroundLocationBroadCastReceiver,
            localBroadcastIntentFilter!!
        )
    }

    override fun onPause() {
        LocalBroadcastManager.getInstance(this@MainActivity)
            .unregisterReceiver(foregroundLocationBroadCastReceiver)
        locationManager!!.stopLocationUpdates()
        super.onPause()
    }

    override fun onRequestPermissionsResult(
        requestCode: Int,
        permissions: Array<String>,
        grantResults: IntArray
    ) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults)
        if (permissionManager!!.handlePermissionResult(
                this@MainActivity, 100, permissions,
                grantResults
            )
        ) {
            locationManager!!.createLocationRequest()
        }
    }

    private var foregroundLocationBroadCastReceiver: BroadcastReceiver =
        object : BroadcastReceiver() {
            override fun onReceive(context: Context, intent: Intent) {
                Log.d("TAG", "Broadcasted")
                Toast.makeText(
                    this@MainActivity,
                    intent.getStringExtra("location"), Toast.LENGTH_SHORT
                ).show()
            }

        }
}